export async function getUser(id) {
  const response = await fetch(`/api/users/${id}`);
  return response.json();
}

export async function pay(amount) {
  const response = await fetch('/api/payments', {
    method: 'POST',
    body: JSON.stringify({ amount })
  });
  return response.json();
}
