package backend.src;
public class UserService {
    public boolean login(String user, String password) {
        if (user == null || password == null) return false;
        return user.equals("admin") && password.equals("admin123");
    }
}
