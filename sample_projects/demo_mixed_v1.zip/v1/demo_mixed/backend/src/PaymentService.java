package backend.src;
public class PaymentService {
    public double calculate(double amount, boolean premium) {
        if (amount <= 0) return 0;
        if (premium) return amount * 0.90;
        return amount;
    }
}
