"""Updated user model for V2."""


class User:
    """Store user details and a simple active state."""

    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.active = True

    def display_name(self):
        """Return a title-cased display name."""
        return self.name.strip().title()

    def contact_summary(self):
        """Return a formatted contact string."""
        return f"{self.display_name()} <{self.email}>"

    def deactivate(self):
        """Mark the user as inactive."""
        self.active = False

    def is_active(self):
        """Return whether the user is active."""
        return self.active
