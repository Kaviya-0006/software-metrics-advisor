"""Greeting service introduced in V2."""


def format_greeting(name):
    """Create a friendly greeting using a cleaned name."""
    clean_name = name.strip().title()
    return f"Welcome, {clean_name}!"


def application_label():
    """Return the label for this sample version."""
    return "Software Metrics Advisor sample V2"
