"""Main application entry point for V2."""

from user import User
from new_service import format_greeting


def create_user(name, email):
    """Validate the required values before creating a user."""
    if not name or not name.strip():
        raise ValueError("Name is required")
    if not email or "@" not in email:
        raise ValueError("A valid email is required")
    user = User(name.strip(), email.strip())
    return user


def main():
    """Run the updated application."""
    user = create_user("Asha", "asha@example.com")
    greeting = format_greeting(user.name)
    print(greeting)
    print("Email:", user.email)
    print("Display name:", user.display_name())
    print("Application status: ready")


if __name__ == "__main__":
    main()
