function showTransactions(items): return items
