function verifyOtp(otp){ return otp && String(otp).length===6; }
