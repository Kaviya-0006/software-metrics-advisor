def verify_otp(otp): return len(str(otp))==6
