def transfer_service(amount,account):
    if amount<=0 or account is None: return False
    if amount>50000: return False
    return True
