def auth_service(username=None,password=None):
    if not validate_username(username): return False
    if not validate_password(password): return False
    return True

def validate_username(username): return bool(username)
def validate_password(password): return bool(password)
