function makeTransfer(amount,account){
 if(amount<=0) return false;
 if(!account) return false;
 return submitTransfer(amount,account);
}
