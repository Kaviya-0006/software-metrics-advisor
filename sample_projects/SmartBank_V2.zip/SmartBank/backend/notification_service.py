def send_notification(message): return bool(message)
