function login(username, password) { return apiLogin(username, password); }
