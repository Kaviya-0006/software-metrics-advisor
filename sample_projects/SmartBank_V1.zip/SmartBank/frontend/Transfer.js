function makeTransfer(amount, account) { return submitTransfer(amount, account); }
