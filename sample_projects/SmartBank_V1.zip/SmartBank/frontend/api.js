function apiLogin(username,password){ return fetch('/api/login'); }
function submitTransfer(amount,account){ return fetch('/api/transfer'); }
