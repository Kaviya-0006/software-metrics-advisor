def transfer_service(amount,account):
    return amount > 0 and account is not None
