def login(): return auth_service()
def transfer(): return transfer_service()
