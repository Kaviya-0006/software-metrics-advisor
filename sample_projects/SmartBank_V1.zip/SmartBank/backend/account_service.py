def get_balance(account): return account
