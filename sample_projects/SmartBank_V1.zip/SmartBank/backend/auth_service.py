def auth_service(username=None,password=None):
    return bool(username and password)
