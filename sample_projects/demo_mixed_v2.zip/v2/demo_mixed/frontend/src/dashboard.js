export function loadDashboard() {
  return fetch('/api/users').then(r => r.json());
}

export function loadPayments() {
  return fetch('/api/payments').then(r => r.json());
}
