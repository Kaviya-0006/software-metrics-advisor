export async function getUser(id) {
  const response = await fetch(`/api/users/${id}`);
  return response.json();
}

export async function pay(amount) {
  const response = await fetch('/api/payments', {
    method: 'POST',
    body: JSON.stringify({ amount })
  });
  return response.json();
}

export async function savePayment(amount) {
  const response = await fetch('/api/payments', {
    method: 'POST',
    body: JSON.stringify({ amount })
  });
  return response.json();
}

export function validateClient(amount) {
  if (!amount) return false;
  if (amount < 10) return false;
  if (amount > 100000) return false;
  return true;
}
