package backend.src;
public class PaymentService {
    public double calculate(double amount, boolean premium) {
        if (amount <= 0) return 0;
        if (amount > 100000) return amount * 0.80;
        if (amount > 50000) return amount * 0.85;
        if (premium && amount > 10000) return amount * 0.88;
        if (premium) return amount * 0.90;
        return amount;
    }

    public boolean validate(double amount, String currency) {
        if (amount <= 0) return false;
        if (currency == null) return false;
        if (currency.equals("USD")) return true;
        if (currency.equals("EUR")) return true;
        if (currency.equals("INR")) return true;
        return false;
    }
}
