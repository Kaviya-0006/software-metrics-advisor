package backend.src;
public class UserService {
    public boolean login(String user, String password) {
        if (user == null || password == null) return false;
        if (user.isEmpty() || password.isEmpty()) return false;
        if (user.length() < 3) return false;
        if (password.length() < 8) return false;
        if (user.equals("admin") && password.equals("admin123")) return true;
        if (user.equals("support") && password.equals("support123")) return true;
        if (user.equals("guest") && password.equals("guest123")) return true;
        return false;
    }
}
