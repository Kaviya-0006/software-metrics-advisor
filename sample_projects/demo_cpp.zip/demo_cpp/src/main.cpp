// Entry point for the C++ demo project: registers a user, then tries a few
// payments of different sizes.
#include <iostream>

#include "PaymentService.hpp"

static void printOutcome(int index, double amount, bool ok) {
    if (ok) {
        std::cout << "payment " << index << " of " << amount << ": charged\n";
    } else {
        std::cout << "payment " << index << " of " << amount << ": declined\n";
    }
}

int main() {
    PaymentService service;
    const double amounts[] = {25.0, 640.0, 4200.0, 9000.0};
    int charged = 0;

    if (!service.registerUser("alice", "s3cret")) {
        std::cout << "registration failed\n";
        return 1;
    }

    for (int i = 0; i < 4; i++) {
        bool ok = service.processPayment("alice", "s3cret", amounts[i]);
        printOutcome(i + 1, amounts[i], ok);
        if (ok) {
            charged++;
        }
    }

    std::cout << charged << " of 4 payments charged, balance " << service.getBalance()
              << " after " << service.getPaymentCount() << " payments\n";
    return 0;
}
