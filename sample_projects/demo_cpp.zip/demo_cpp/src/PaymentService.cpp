// Payment processing for the C++ demo project (see PaymentService.hpp).
#include "PaymentService.hpp"

PaymentService::PaymentService() : AuthService(), balance(5000.0) {}

bool PaymentService::processPayment(const std::string& name, const std::string& password, double amount) {
    if (!authenticate(name, password)) {
        return false;
    }
    if (amount <= 0) {
        return false;
    }

    int tier = classifyAmount(amount);
    double charge = applyFee(amount, tier);
    if (charge > balance) {
        return false;
    }

    balance -= charge;
    payments.push_back(charge);
    return true;
}

// Amount tiers: 1 = small, 2 = medium, 3 = large.
int PaymentService::classifyAmount(double amount) const {
    if (amount < 100) {
        return 1;
    } else if (amount < 1000) {
        return 2;
    }
    return 3;
}

// Larger payments pay a smaller percentage fee.
double PaymentService::applyFee(double amount, int tier) const {
    switch (tier) {
    case 1:
        return amount * 1.03;
    case 2:
        return amount * 1.02;
    case 3:
        return amount * 1.01;
    default:
        return amount;
    }
}

double PaymentService::getBalance() const {
    return balance;
}

int PaymentService::getPaymentCount() const {
    return static_cast<int>(payments.size());
}

// Account names follow the same rules as user names. The loop below is
// copy-pasted from AuthService.cpp on purpose, so the duplication metric
// has something to find.
bool PaymentService::isValidAccount(const std::string& name) const {
    if (name.empty()) {
        return false;
    }
    for (std::size_t i = 0; i < name.size(); i++) {
        char c = name[i];
        if (!std::isalnum(static_cast<unsigned char>(c)) && c != '_') {
            return false;
        }
    }
    return true;
}
