// Authentication service for the C++ demo project (see AuthService.hpp).
#include "AuthService.hpp"

AuthService::AuthService() : maxAttempts(3), failedAttempts(0) {}

bool AuthService::registerUser(const std::string& name, const std::string& password) {
    if (!isValidName(name) || password.empty()) {
        return false;
    }
    if (users.count(name) > 0) {
        return false;
    }
    users[name] = password;
    return true;
}

// Checks the password and applies naive rate limiting.
bool AuthService::authenticate(const std::string& name, const std::string& password) {
    recordCall();

    if (failedAttempts >= maxAttempts) {
        return false;
    }

    std::map<std::string, std::string>::const_iterator it = users.find(name);
    if (it == users.end()) {
        failedAttempts++;
        return false;
    }
    if (it->second == password) {
        failedAttempts = 0;
        return true;
    }

    failedAttempts++;
    return false;
}

bool AuthService::isValidName(const std::string& name) const {
    if (name.size() < 3 || name.size() > 32) {
        return false;
    }
    for (std::size_t i = 0; i < name.size(); i++) {
        char c = name[i];
        if (!std::isalnum(static_cast<unsigned char>(c)) && c != '_') {
            return false;
        }
    }
    return true;
}
