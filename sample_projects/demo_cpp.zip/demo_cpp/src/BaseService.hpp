// Root of the C++ demo's inheritance chain:
//   BaseService -> AuthService -> PaymentService
//
// A deliberately small sample used to demonstrate the metrics engine on
// C++ source code - not a production design. This class is header-only
// (all methods are inline), which lets the analyzer measure its cohesion.
#ifndef BASE_SERVICE_HPP
#define BASE_SERVICE_HPP

class BaseService {
protected:
    int callCount;

public:
    BaseService() : callCount(0) {}
    virtual ~BaseService() {}

    int getCallCount() const { return callCount; }
    void resetCallCount() { callCount = 0; }

protected:
    void recordCall() { callCount++; }
};

#endif
