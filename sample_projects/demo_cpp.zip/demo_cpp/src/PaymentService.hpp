// Payment service: third level of the inheritance chain
//   BaseService -> AuthService -> PaymentService
#ifndef PAYMENT_SERVICE_HPP
#define PAYMENT_SERVICE_HPP

#include <vector>

#include "AuthService.hpp"

class PaymentService : public AuthService {
public:
    PaymentService();

    bool processPayment(const std::string& name, const std::string& password, double amount);
    double getBalance() const;
    int getPaymentCount() const;
    bool isValidAccount(const std::string& name) const;

private:
    int classifyAmount(double amount) const;
    double applyFee(double amount, int tier) const;

    double balance;
    std::vector<double> payments;
};

#endif
