// Authentication service: second level of the inheritance chain.
#ifndef AUTH_SERVICE_HPP
#define AUTH_SERVICE_HPP

#include <cctype>
#include <cstddef>
#include <map>
#include <string>

#include "BaseService.hpp"

class AuthService : public BaseService {
public:
    AuthService();

    bool registerUser(const std::string& name, const std::string& password);
    bool authenticate(const std::string& name, const std::string& password);
    bool isValidName(const std::string& name) const;

protected:
    int maxAttempts;

private:
    std::map<std::string, std::string> users;
    int failedAttempts;
};

#endif
