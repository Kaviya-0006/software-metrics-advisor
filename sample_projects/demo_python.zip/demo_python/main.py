"""
Entry point tying the demo project's auth and user modules together.
"""

from auth import AuthError, create_default_authenticator
from user import User, UserRepository, ValidationError


def register_user(repository, entity_id, username, email):
    if not username or not email:
        raise ValidationError("Username and email are required")

    user = User(entity_id, username, email)
    if not user.is_valid_username(username):
        raise ValidationError("Invalid username")

    repository.add(user)
    return user


def run_demo():
    repository = UserRepository()
    authenticator = create_default_authenticator()

    try:
        register_user(repository, 1, "demo_user", "demo@example.com")
    except ValidationError as exc:
        print(f"Registration failed: {exc}")
        return

    try:
        authenticator.authenticate("demo_user", "wrong-password")
    except AuthError as exc:
        print(f"Login failed: {exc}")

    print(f"Total users: {repository.count()}")


if __name__ == "__main__":
    run_demo()
