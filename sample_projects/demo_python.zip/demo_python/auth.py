"""
Authentication helpers for the demo project.

This is a deliberately small sample used to sanity-check the metrics
engine (Phase 2) against real, varied source code — not a production
auth system.
"""

import hashlib
import re


class AuthError(Exception):
    """Raised when authentication fails for a recognizable reason."""
    pass


class BaseAuthenticator:
    def __init__(self):
        self.attempts = 0

    def authenticate(self, username, password):
        raise NotImplementedError


class PasswordAuthenticator(BaseAuthenticator):
    """Simple username/password authenticator with naive rate limiting."""

    def __init__(self, users):
        super().__init__()
        self.users = users
        self.max_attempts = 3

    def authenticate(self, username, password):
        if not username or not password:
            raise AuthError("Missing credentials")

        if self.attempts >= self.max_attempts:
            raise AuthError("Too many attempts")

        if username not in self.users:
            self.attempts += 1
            raise AuthError("Unknown user")

        expected_hash = self.users[username]
        actual_hash = self._hash_password(password)

        if actual_hash == expected_hash:
            self.attempts = 0
            return True
        else:
            self.attempts += 1
            return False

    def _hash_password(self, password):
        return hashlib.sha256(password.encode("utf-8")).hexdigest()

    def is_valid_username(self, username):
        if not username:
            return False
        if len(username) < 3 or len(username) > 32:
            return False
        return bool(re.match(r"^[a-zA-Z0-9_]+$", username))


def create_default_authenticator():
    users = {}
    return PasswordAuthenticator(users)
