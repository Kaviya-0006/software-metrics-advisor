"""
User model and repository for the demo project.
"""

import re


class ValidationError(Exception):
    pass


class Entity:
    def __init__(self, entity_id):
        self.entity_id = entity_id

    def describe(self):
        return f"Entity#{self.entity_id}"


class User(Entity):
    """A user record. Deliberately duplicates the username-validation
    logic from auth.py so the duplication metric has something real to
    detect across files."""

    def __init__(self, entity_id, username, email):
        super().__init__(entity_id)
        self.username = username
        self.email = email
        self.roles = []

    def is_valid_username(self, username):
        if not username:
            return False
        if len(username) < 3 or len(username) > 32:
            return False
        return bool(re.match(r"^[a-zA-Z0-9_]+$", username))

    def add_role(self, role):
        if role not in self.roles:
            self.roles.append(role)

    def has_role(self, role):
        return role in self.roles

    def describe(self):
        return f"User({self.username})"


class UserRepository:
    def __init__(self):
        self._users = {}

    def add(self, user):
        if not isinstance(user, User):
            raise ValidationError("Expected a User instance")
        self._users[user.entity_id] = user

    def get(self, entity_id):
        if entity_id in self._users:
            return self._users[entity_id]
        return None

    def find_by_role(self, role):
        results = []
        for user in self._users.values():
            if user.has_role(role):
                results.append(user)
        return results

    def count(self):
        return len(self._users)
