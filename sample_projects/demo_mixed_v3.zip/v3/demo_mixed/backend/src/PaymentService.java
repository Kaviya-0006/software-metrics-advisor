package backend.src;
public class PaymentService {
    public double calculate(double amount, boolean premium) {
        if (amount <= 0) return 0;
        double rate = premium ? 0.90 : 1.0;
        if (amount > 100000) rate = 0.80;
        else if (amount > 50000) rate = 0.85;
        else if (premium && amount > 10000) rate = 0.88;
        return amount * rate;
    }
    public boolean validate(double amount, String currency) {
        return amount > 0 && currency != null &&
            (currency.equals("USD") || currency.equals("EUR") || currency.equals("INR"));
    }
}
