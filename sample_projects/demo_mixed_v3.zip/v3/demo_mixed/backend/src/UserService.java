package backend.src;
public class UserService {
    public boolean login(String user, String password) {
        if (!validInput(user, password)) return false;
        return isKnownUser(user, password);
    }
    private boolean validInput(String user, String password) {
        return user != null && password != null && !user.isEmpty() && password.length() >= 8;
    }
    private boolean isKnownUser(String user, String password) {
        return (user.equals("admin") && password.equals("admin123"))
            || (user.equals("support") && password.equals("support123"));
    }
}
