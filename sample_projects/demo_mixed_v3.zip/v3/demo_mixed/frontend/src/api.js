async function request(url, options) {
  const response = await fetch(url, options);
  return response.json();
}
export function getUser(id) { return request(`/api/users/${id}`); }
export function pay(amount) { return request('/api/payments', { method: 'POST', body: JSON.stringify({ amount }) }); }
export function savePayment(amount) { return pay(amount); }
export function validateClient(amount) { return amount >= 10 && amount <= 100000; }
