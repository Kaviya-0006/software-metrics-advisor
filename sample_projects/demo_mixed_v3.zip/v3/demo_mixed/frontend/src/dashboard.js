import { request } from './shared.js';
export function loadDashboard() { return request('/api/users'); }
export function loadPayments() { return request('/api/payments'); }
