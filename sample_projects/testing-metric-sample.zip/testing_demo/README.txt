Testing Metric Sample Project

Production files:
- 2 Python files
- 2 JavaScript files

Test files:
- 2 Python test files
- 2 JavaScript test files

This ZIP is intentionally designed to test whether the Software Metrics
Advisor detects test files and produces a non-zero Testing score.
