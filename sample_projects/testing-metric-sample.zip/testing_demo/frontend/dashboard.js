export function renderUsers(users) {
    return users.map(user => `<div>${user.name}</div>`).join("");
}
