class UserService:
    def validate_user(self, username):
        return username is not None and username != ""

    def get_role(self, username):
        return "ADMIN" if username == "admin" else "USER"
