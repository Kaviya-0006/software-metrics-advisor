from backend.user_service import UserService

def test_validate_user():
    service = UserService()
    assert service.validate_user("kaviya") is True

def test_get_role():
    service = UserService()
    assert service.get_role("admin") == "ADMIN"
