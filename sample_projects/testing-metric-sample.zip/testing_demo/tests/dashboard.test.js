import { renderUsers } from "../frontend/dashboard.js";

test("renderUsers exists", () => {
    expect(typeof renderUsers).toBe("function");
});
