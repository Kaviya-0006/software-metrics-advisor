import { getUsers } from "../frontend/api.js";

test("getUsers exists", () => {
    expect(typeof getUsers).toBe("function");
});
