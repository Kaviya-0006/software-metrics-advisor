'use strict';

/**
 * Root of the JavaScript demo's inheritance chain:
 *   BaseService -> AuthService -> PaymentService
 *
 * A deliberately small sample used to demonstrate the metrics engine on
 * JavaScript source code - not a production design.
 */
class BaseService {
  constructor() {
    this.callCount = 0;
  }

  recordCall() {
    this.callCount += 1;
  }

  getCallCount() {
    return this.callCount;
  }

  resetCallCount() {
    this.callCount = 0;
  }
}

module.exports = { BaseService };
