'use strict';

/*
 * Entry point for the JavaScript demo project: registers a user, then tries
 * a few payments of different sizes.
 */
const { PaymentService } = require('./paymentService');

const formatAmount = (amount) => amount.toFixed(2);

function run() {
  const service = new PaymentService();
  const amounts = [25, 640, 4200, 9000];
  let charged = 0;

  if (!service.register('alice', 's3cret')) {
    console.log('registration failed');
    return 1;
  }

  for (const amount of amounts) {
    const ok = service.processPayment('alice', 's3cret', amount);
    console.log(`payment of ${formatAmount(amount)}: ${ok ? 'charged' : 'declined'}`);
    if (ok) {
      charged += 1;
    }
  }

  console.log(
    `${charged} of ${amounts.length} payments charged, ` +
      `balance ${formatAmount(service.balance)}, total ${formatAmount(service.totalPaid())}`
  );
  return 0;
}

process.exitCode = run();
