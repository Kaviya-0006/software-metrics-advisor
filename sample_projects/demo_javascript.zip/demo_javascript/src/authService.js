'use strict';

const crypto = require('crypto');
const { BaseService } = require('./baseService');

/** Hashes a password. Fine for a demo, never for real credentials. */
const hashPassword = (password) =>
  crypto.createHash('sha256').update(password).digest('hex');

/** Second level of the inheritance chain: registration and login. */
class AuthService extends BaseService {
  constructor() {
    super();
    this.users = new Map();
    this.failedAttempts = 0;
    this.maxAttempts = 3;
  }

  register(name, password) {
    if (!this.isValidName(name) || !password) {
      return false;
    }
    if (this.users.has(name)) {
      return false;
    }
    this.users.set(name, hashPassword(password));
    return true;
  }

  // Checks the password and applies naive rate limiting.
  authenticate(name, password) {
    this.recordCall();

    if (this.failedAttempts >= this.maxAttempts) {
      return false;
    }

    const stored = this.users.get(name);
    if (stored === undefined) {
      this.failedAttempts += 1;
      return false;
    }
    if (stored === hashPassword(password)) {
      this.failedAttempts = 0;
      return true;
    }

    this.failedAttempts += 1;
    return false;
  }

  isValidName(name) {
    if (typeof name !== 'string' || name.length < 3 || name.length > 32) {
      return false;
    }
    for (let i = 0; i < name.length; i++) {
      const c = name[i];
      if (!/[A-Za-z0-9_]/.test(c)) {
        return false;
      }
    }
    return true;
  }
}

module.exports = { AuthService, hashPassword };
