'use strict';

const { AuthService } = require('./authService');

const FEES = { 1: 1.03, 2: 1.02, 3: 1.01 };

/** Amount tiers: 1 = small, 2 = medium, 3 = large. */
const classifyAmount = (amount) => {
  if (amount < 100) {
    return 1;
  } else if (amount < 1000) {
    return 2;
  }
  return 3;
};

/** Third level of the inheritance chain: charges payments. */
class PaymentService extends AuthService {
  constructor(balance = 5000) {
    super();
    this.balance = balance;
    this.payments = [];
  }

  processPayment(name, password, amount) {
    if (!this.authenticate(name, password) || amount <= 0) {
      return false;
    }

    const charge = this.applyFee(amount, classifyAmount(amount));
    if (charge > this.balance) {
      return false;
    }

    this.balance -= charge;
    this.payments.push(charge);
    return true;
  }

  // Larger payments pay a smaller percentage fee.
  applyFee(amount, tier) {
    switch (tier) {
      case 1:
        return amount * FEES[1];
      case 2:
        return amount * FEES[2];
      case 3:
        return amount * FEES[3];
      default:
        return amount;
    }
  }

  totalPaid() {
    let total = 0;
    for (const payment of this.payments) {
      if (payment > 0) {
        total += payment;
      }
    }
    return total;
  }

  // Account names follow the same rules as user names. The loop below is
  // copy-pasted from authService.js on purpose, so the duplication metric
  // has something to find.
  isValidAccount(name) {
    if (typeof name !== 'string') {
      return false;
    }
    for (let i = 0; i < name.length; i++) {
      const c = name[i];
      if (!/[A-Za-z0-9_]/.test(c)) {
        return false;
      }
    }
    return true;
  }
}

module.exports = { PaymentService, classifyAmount };
