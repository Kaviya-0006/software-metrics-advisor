package demo;

public class UserService {
    public boolean validateUser(String username, String password) {
        if (username == null || password == null) return false;
        if (username.isEmpty()) return false;
        if (password.length() < 6) return false;
        return true;
    }
}
