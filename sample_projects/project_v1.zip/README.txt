Demo project version V1. Baseline with one Java service and one JavaScript API module.
