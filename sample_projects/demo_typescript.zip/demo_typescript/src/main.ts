/*
 * Entry point for the TypeScript demo project: registers a user, then tries
 * a few payments of different sizes.
 */
import { PaymentService } from './paymentService';
import { PaymentResult } from './types';

const formatAmount = (amount: number): string => amount.toFixed(2);

function run(): number {
  const service = new PaymentService();
  const amounts: number[] = [25, 640, 4200, 9000];
  let charged = 0;

  if (!service.register('alice', 's3cret')) {
    console.log('registration failed');
    return 1;
  }

  for (const amount of amounts) {
    const result: PaymentResult = service.processPayment('alice', 's3cret', amount);
    console.log(`payment of ${formatAmount(amount)}: ${result.ok ? 'charged' : result.reason}`);
    if (result.ok) {
      charged += 1;
    }
  }

  console.log(
    `${charged} of ${amounts.length} payments charged, ` +
      `balance ${formatAmount(service.getBalance())}, total ${formatAmount(service.totalPaid())}`
  );
  return 0;
}

run();
