import { BaseService } from './baseService';
import { Authenticator, User } from './types';

/** djb2 string hash. Fine for a demo, never for real credentials. */
export function hashPassword(password: string): string {
  let hash = 5381;
  for (let i = 0; i < password.length; i++) {
    hash = (hash * 33 + password.charCodeAt(i)) % 4294967296;
  }
  return hash.toString(16);
}

/** Second level of the inheritance chain: registration and login. */
export class AuthService extends BaseService implements Authenticator {
  private users: Map<string, User> = new Map();
  protected maxAttempts: number = 3;

  describe(): string {
    return `AuthService with ${this.users.size} users`;
  }

  register(name: string, password: string): boolean {
    if (!this.isValidName(name) || password.length === 0) {
      return false;
    }
    if (this.users.has(name)) {
      return false;
    }
    this.users.set(name, { name, passwordHash: hashPassword(password), failedAttempts: 0 });
    return true;
  }

  // Checks the password and applies naive rate limiting.
  authenticate(name: string, password: string): boolean {
    this.recordCall();

    const user = this.users.get(name);
    if (user === undefined || user.failedAttempts >= this.maxAttempts) {
      return false;
    }
    if (user.passwordHash === hashPassword(password)) {
      user.failedAttempts = 0;
      return true;
    }

    user.failedAttempts += 1;
    return false;
  }

  isValidName(name: string): boolean {
    if (name.length < 3 || name.length > 32) {
      return false;
    }
    for (let i = 0; i < name.length; i++) {
      const c: string = name[i];
      if (!/[A-Za-z0-9_]/.test(c)) {
        return false;
      }
    }
    return true;
  }
}
