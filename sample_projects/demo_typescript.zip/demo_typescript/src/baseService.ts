/**
 * Root of the TypeScript demo's inheritance chain:
 *   BaseService -> AuthService -> PaymentService
 */
export abstract class BaseService {
  protected callCount: number = 0;

  protected recordCall(): void {
    this.callCount += 1;
  }

  getCallCount(): number {
    return this.callCount;
  }

  resetCallCount(): void {
    this.callCount = 0;
  }

  abstract describe(): string;
}
