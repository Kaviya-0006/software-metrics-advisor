import { AuthService } from './authService';
import { PaymentResult, PaymentTier } from './types';

const FEES: Record<PaymentTier, number> = { 1: 1.03, 2: 1.02, 3: 1.01 };

/** Amount tiers: 1 = small, 2 = medium, 3 = large. */
export function classifyAmount(amount: number): PaymentTier {
  if (amount < 100) {
    return 1;
  } else if (amount < 1000) {
    return 2;
  }
  return 3;
}

/** Third level of the inheritance chain: charges payments. */
export class PaymentService extends AuthService {
  private balance: number;
  private payments: number[] = [];

  constructor(balance: number = 5000) {
    super();
    this.balance = balance;
  }

  describe(): string {
    return `PaymentService with balance ${this.balance}`;
  }

  processPayment(name: string, password: string, amount: number): PaymentResult {
    if (!this.authenticate(name, password)) {
      return { ok: false, charged: 0, reason: 'authentication failed' };
    }
    if (amount <= 0) {
      return { ok: false, charged: 0, reason: 'invalid amount' };
    }

    const charge = this.applyFee(amount, classifyAmount(amount));
    if (charge > this.balance) {
      return { ok: false, charged: 0, reason: 'insufficient balance' };
    }

    this.balance -= charge;
    this.payments.push(charge);
    return { ok: true, charged: charge };
  }

  // Larger payments pay a smaller percentage fee.
  applyFee(amount: number, tier: PaymentTier): number {
    switch (tier) {
      case 1:
        return amount * FEES[1];
      case 2:
        return amount * FEES[2];
      case 3:
        return amount * FEES[3];
      default:
        return amount;
    }
  }

  getBalance(): number {
    return this.balance;
  }

  totalPaid(): number {
    let total = 0;
    for (const payment of this.payments) {
      if (payment > 0) {
        total += payment;
      }
    }
    return total;
  }

  // Account names follow the same rules as user names. The loop below is
  // copy-pasted from authService.ts on purpose, so the duplication metric
  // has something to find.
  isValidAccount(name: string): boolean {
    if (name.length === 0) {
      return false;
    }
    for (let i = 0; i < name.length; i++) {
      const c: string = name[i];
      if (!/[A-Za-z0-9_]/.test(c)) {
        return false;
      }
    }
    return true;
  }
}
