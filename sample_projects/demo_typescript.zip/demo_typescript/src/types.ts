/**
 * Shared types for the TypeScript demo project.
 *
 * A deliberately small sample used to demonstrate the metrics engine on
 * TypeScript source code - not a production design.
 */

export interface User {
  name: string;
  passwordHash: string;
  failedAttempts: number;
}

/** Fee tiers for payments, from small to large. */
export type PaymentTier = 1 | 2 | 3;

export type PaymentResult = { ok: boolean; charged: number; reason?: string };

export interface Authenticator {
  authenticate(name: string, password: string): boolean;
}
