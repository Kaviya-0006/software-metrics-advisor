package com.example.demo;

public abstract class BaseService {
    protected int callCount;

    public BaseService() {
        this.callCount = 0;
    }

    public int getCallCount() {
        return callCount;
    }

    protected void recordCall() {
        callCount++;
    }
}
