package com.example.demo;

import java.util.HashMap;
import java.util.Map;

public class AuthService extends BaseService {
    private Map<String, String> users;
    private int attempts;
    private int maxAttempts;

    public AuthService() {
        super();
        this.users = new HashMap<>();
        this.attempts = 0;
        this.maxAttempts = 3;
    }

    public boolean authenticate(String username, String password) {
        recordCall();

        if (username == null || password == null) {
            return false;
        }

        if (attempts >= maxAttempts) {
            return false;
        }

        if (!users.containsKey(username)) {
            attempts++;
            return false;
        }

        String expected = users.get(username);
        if (expected.equals(password)) {
            attempts = 0;
            return true;
        } else {
            attempts++;
            return false;
        }
    }

    public void registerUser(String username, String password) {
        if (username == null || username.length() < 3) {
            throw new IllegalArgumentException("Invalid username");
        }
        users.put(username, password);
    }

    public boolean isValidUsername(String username) {
        if (username == null) {
            return false;
        }
        for (int i = 0; i < username.length(); i++) {
            char c = username.charAt(i);
            if (!Character.isLetterOrDigit(c) && c != '_') {
                return false;
            }
        }
        return username.length() >= 3 && username.length() <= 32;
    }
}
