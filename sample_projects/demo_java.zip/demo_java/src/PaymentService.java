package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class PaymentService extends AuthService {
    private List<Double> transactions;
    private double balance;

    public PaymentService() {
        super();
        this.transactions = new ArrayList<>();
        this.balance = 0.0;
    }

    public boolean processPayment(String username, String password, double amount) {
        if (!authenticate(username, password)) {
            return false;
        }

        if (amount <= 0) {
            return false;
        }

        switch (classifyAmount(amount)) {
            case 1:
                balance -= amount;
                break;
            case 2:
                balance -= amount * 0.98; // small discount tier
                break;
            default:
                balance -= amount;
        }

        transactions.add(amount);
        return true;
    }

    private int classifyAmount(double amount) {
        if (amount < 100) {
            return 1;
        } else if (amount < 1000) {
            return 2;
        }
        return 3;
    }

    public double getBalance() {
        return balance;
    }

    public int getTransactionCount() {
        return transactions.size();
    }
}
