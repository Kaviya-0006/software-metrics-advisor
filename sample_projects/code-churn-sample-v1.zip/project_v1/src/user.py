"""Simple user model for V1."""


class User:
    """Store a user's basic details."""

    def __init__(self, name, email):
        self.name = name
        self.email = email

    def display_name(self):
        """Return the name without changes."""
        return self.name

    def contact_summary(self):
        """Return a simple contact string."""
        return f"{self.name} <{self.email}>"
