"""Main application entry point for V1."""

from user import User
from old_helper import format_greeting


def create_user(name, email):
    """Create a user using the original flow."""
    user = User(name, email)
    return user


def main():
    """Run the original application."""
    user = create_user("Asha", "asha@example.com")
    greeting = format_greeting(user.name)
    print(greeting)
    print("Email:", user.email)


if __name__ == "__main__":
    main()
