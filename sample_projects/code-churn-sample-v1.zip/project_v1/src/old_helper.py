"""Legacy helper functions used in V1."""


def format_greeting(name):
    """Create a basic greeting."""
    clean_name = name.strip()
    return f"Hello, {clean_name}!"


def make_user_label(name, email):
    """Create a label for a user."""
    return f"{name} ({email})"


def legacy_status():
    """Return the legacy status message."""
    return "Legacy helper is active."
