/*
 * Authentication helpers for the C demo project (see auth.h).
 */
#include <string.h>

#include "auth.h"

#define MAX_ATTEMPTS 3

/* Returns 1 for a 3-32 character name made of letters, digits or '_'. */
int is_valid_username(const char *name)
{
    int i;
    int length;

    if (name == NULL) {
        return 0;
    }

    length = (int)strlen(name);
    if (length < 3 || length > MAX_NAME_LEN) {
        return 0;
    }

    for (i = 0; i < length; i++) {
        char c = name[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_')) {
            return 0;
        }
    }
    return 1;
}

/* djb2 string hash - good enough for a demo, never for real passwords. */
unsigned long hash_password(const char *password)
{
    unsigned long hash = 5381;
    int i;

    for (i = 0; password[i] != '\0'; i++) {
        hash = hash * 33 + (unsigned char)password[i];
    }
    return hash;
}

/* Checks the password and applies naive rate limiting. */
int authenticate(struct User *user, const char *password)
{
    if (user == NULL || password == NULL) {
        return 0;
    }

    if (user->failed_attempts >= MAX_ATTEMPTS) {
        return 0;
    }

    if (hash_password(password) == user->password_hash) {
        user->failed_attempts = 0;
        return 1;
    } else {
        user->failed_attempts++;
        return 0;
    }
}

/* Returns the index of the user called `name`, or -1 when not found. */
int find_user(const struct User *users, int count, const char *name)
{
    int i;

    for (i = 0; i < count; i++) {
        if (strcmp(users[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}
