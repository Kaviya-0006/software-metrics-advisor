/*
 * Entry point for the C demo project: registers a user, then tries a few
 * payments of different sizes.
 */
#include <stdio.h>

#include "auth.h"
#include "payment.h"

static void print_result(int id, double amount, int ok)
{
    if (ok) {
        printf("payment %d of %.2f: charged\n", id, amount);
    } else {
        printf("payment %d of %.2f: declined\n", id, amount);
    }
}

int main(void)
{
    struct User users[MAX_USERS];
    struct Payment payments[4] = {
        {1, 25.0, 0}, {2, 640.0, 0}, {3, 4200.0, 0}, {4, 9000.0, 0}
    };
    double balance = 5000.0;
    int charged = 0;
    int index;
    int i;

    users[0] = (struct User){"alice", hash_password("s3cret"), 0};

    if (!is_valid_username(users[0].name)) {
        printf("invalid user name\n");
        return 1;
    }

    index = find_user(users, 1, "alice");
    for (i = 0; i < 4; i++) {
        int ok = process_payment(&users[index], "s3cret", &payments[i], &balance);
        print_result(payments[i].id, payments[i].amount, ok);
        if (ok) {
            charged++;
        }
    }

    printf("%d of 4 payments charged, balance %.2f (requested %.2f)\n",
           charged, balance, total_payments(payments, 4));
    return 0;
}
