/*
 * Authentication helpers for the C demo project.
 *
 * A deliberately small sample used to demonstrate the metrics engine on C
 * source code - not a production authentication system.
 */
#ifndef AUTH_H
#define AUTH_H

#define MAX_NAME_LEN 32
#define MAX_USERS 8

/* A registered user: a struct is the C counterpart of a small class. */
struct User {
    char name[MAX_NAME_LEN + 1];
    unsigned long password_hash;
    int failed_attempts;
};

int is_valid_username(const char *name);
unsigned long hash_password(const char *password);
int authenticate(struct User *user, const char *password);
int find_user(const struct User *users, int count, const char *name);

#endif
