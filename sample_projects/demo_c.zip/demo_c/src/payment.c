/*
 * Payment processing for the C demo project (see payment.h).
 */
#include <string.h>

#include "payment.h"

/* Amount tiers: 1 = small, 2 = medium, 3 = large. */
int classify_amount(double amount)
{
    if (amount < 100.0) {
        return 1;
    } else if (amount < 1000.0) {
        return 2;
    }
    return 3;
}

/* Larger payments pay a smaller percentage fee. */
double apply_fee(double amount, int tier)
{
    switch (tier) {
    case 1:
        return amount * 1.03;
    case 2:
        return amount * 1.02;
    case 3:
        return amount * 1.01;
    default:
        return amount;
    }
}

/* Authenticates, classifies and charges one payment against `balance`. */
int process_payment(struct User *user, const char *password,
                    struct Payment *payment, double *balance)
{
    double charge;

    if (!authenticate(user, password)) {
        return 0;
    }
    if (payment->amount <= 0.0) {
        return 0;
    }

    payment->tier = classify_amount(payment->amount);
    charge = apply_fee(payment->amount, payment->tier);
    if (charge > *balance) {
        return 0;
    }

    *balance -= charge;
    return 1;
}

double total_payments(const struct Payment *payments, int count)
{
    int i;
    double total = 0.0;

    for (i = 0; i < count; i++) {
        if (payments[i].amount > 0.0) {
            total += payments[i].amount;
        }
    }
    return total;
}

/* Account names follow the same rules as user names. The loop below is
 * copy-pasted from auth.c on purpose, so the duplication metric has
 * something to find. */
int is_valid_account_name(const char *name)
{
    int i;
    int length = (int)strlen(name);

    for (i = 0; i < length; i++) {
        char c = name[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_')) {
            return 0;
        }
    }
    return 1;
}
