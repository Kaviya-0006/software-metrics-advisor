/*
 * Payment helpers for the C demo project (builds on auth.h).
 */
#ifndef PAYMENT_H
#define PAYMENT_H

#include "auth.h"

/* A single payment record. */
struct Payment {
    int id;
    double amount;
    int tier;
};

int classify_amount(double amount);
double apply_fee(double amount, int tier);
int process_payment(struct User *user, const char *password,
                    struct Payment *payment, double *balance);
double total_payments(const struct Payment *payments, int count);
int is_valid_account_name(const char *name);

#endif
