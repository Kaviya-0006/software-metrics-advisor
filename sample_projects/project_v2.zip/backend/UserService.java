package demo;

public class UserService {
    public boolean validateUser(String username, String password) {
        if (username == null || password == null) return false;
        if (username.isEmpty()) return false;
        if (password.length() < 6) return false;
        if (username.contains(" ")) return false;
        return true;
    }

    public String getUserRole(String username) {
        if (username == null) return "GUEST";
        if (username.startsWith("admin")) return "ADMIN";
        if (username.startsWith("staff")) return "STAFF";
        return "USER";
    }
}
