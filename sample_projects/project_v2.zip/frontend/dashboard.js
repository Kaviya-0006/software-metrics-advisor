export function renderDashboard(users) {
    const container = document.getElementById("users");
    container.innerHTML = users.map(u => `<div>${u.name}</div>`).join("");
}
