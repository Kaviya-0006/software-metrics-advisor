export async function getUsers() {
    const response = await fetch("/api/users");
    return response.json();
}

export async function getUserRole(username) {
    const response = await fetch("/api/users/" + username + "/role");
    return response.json();
}
