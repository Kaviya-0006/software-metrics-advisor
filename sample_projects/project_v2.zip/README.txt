Demo project version V2. Adds role handling, an API call, and a dashboard module.
